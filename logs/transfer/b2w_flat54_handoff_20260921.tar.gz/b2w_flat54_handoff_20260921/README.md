# B2W Flat54 handoff

1. Clone or update https://github.com/TTSPROD/B2W_RL_IsaacLab and checkout commit 5add7c9de63ab44ae8e3f250f59e05f74452478d.
2. Extract this archive outside the repository.
3. Verify every payload file against manifest.json before copying.
4. Copy the contents of payload into the repository root, preserving paths.
5. Recreate the documented Python 3.11 / Isaac Sim 5.1.0 / Isaac Lab v2.3.2 / RSL-RL 3.1.2 runtime; runtime and .venv are not included.
6. Run CPU tests and a fresh GPU preflight on the destination PC before training.

Canonical next parent: qualified Flat seed54. Failed U1/U1.1/U1.2 checkpoints are intentionally excluded. No live robot actuation is authorized.
